window.onload = function() {
    
    setTimeout(function() {
        document.getElementById('loading').style.display = 'none';  
        document.querySelector('.content').style.display = 'block';  
    }, 600); 
};
