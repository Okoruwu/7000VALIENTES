
document.addEventListener("DOMContentLoaded", function() {
    console.log("Marquee cargado correctamente.");
});
